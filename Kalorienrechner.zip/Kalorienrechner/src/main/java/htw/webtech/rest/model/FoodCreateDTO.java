package htw.webtech.rest.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;


public record FoodCreateDTO(
        @NotBlank String name,
        @NotNull @PositiveOrZero Double protein,
        @NotNull @PositiveOrZero Double carbs,
        @NotNull @PositiveOrZero Double fat,
        Long categoryId
) {}